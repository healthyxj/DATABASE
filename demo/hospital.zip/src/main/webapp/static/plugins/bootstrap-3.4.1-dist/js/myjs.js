function test(){
    window.alert("你好");
}

function ajaxValidate(){
    var userid = $("#userid").val();
    $.ajax({
        type: "POST",
        url: "${pageContext.request.contextPath}/doctor/checkid",
        data: "userid="+userid,
        datatype: "json",    //返回的json格式
        cathe: false,
        success:function(data){
            window.alert("这是测试是否进入success的");
            var msg = data.responseJSON;
            window.alert(data);
            if(msg == true){
                $("#userid_span").html("<font color='red'>用户ID已被注册</font>");
                window.alert("success:用户ID已被注册");
            }else{
                $("#userid_span").html("");
                window.alert("success:用户名可以使用");
            }
        },
        error:function (data) {
            //console.log("进入error");
            //window.alert(JSON.stringify(data));
            //console.log("打印data:" + JSON.stringify(data));
            var msg = data.responseJSON;
            //console.log("打印msg的结果:" + msg);
            if(msg == true){ //true不用加引号
                $("#userid_span").html("<font color='blue'>用户ID可以使用</font>");
                //window.alert("用户ID可以使用");
            }else{
                $("#userid_span").html("<font color='red'>用户ID已被注册</font>");
                //window.alert("用户ID已被注册");
            }
        }
    });
}

function ajaxValidate2(){
    var userid = $("#userid").val();
    $.ajax({
        type: "POST",
        url: "${pageContext.request.contextPath}/doctor/checkid",
        data: "userid="+userid,
        datatype: "json",    //返回的json格式
        cathe: false,
        success:function(data){
            //window.alert("这是测试是否进入success的");
            var msg = data.responseJSON;
            window.alert(data);
            if(msg == true){
                $("#userid_span").html("<font color='red'>用户ID已被注册</font>");
            }else{
                $("#userid_span").html("");
            }
        },
        error:function (data) {
            var msg = data.responseJSON;
            if(msg == true){ //true不用加引号
                $("#userid_span").html("<font color='blue'>用户名可以使用</font>");
            }else{
                $("#userid_span").html("<font color='red'>用户ID已被注册</font>");
            }
        }
    });
}