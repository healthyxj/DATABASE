package cn.doc.controller;

import cn.doc.entity.Doctor;
import cn.doc.entity.Message;
import cn.doc.entity.Patient;
import cn.doc.service.DoctorService;
import cn.doc.service.PatientService;
import com.github.pagehelper.PageInfo;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import javax.annotation.Resource;
import javax.json.Json;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.io.IOException;
import java.util.List;

@Controller
@RequestMapping("/doctor")
public class DoctorController {

    @Resource
    private DoctorService doctorService;

    @Resource
    private PatientService patientService;

    //进入首页，可能累赘
    @RequestMapping("/nav")
    public String jmpToNavigator(HttpSession httpSession,
                                 Model model){
        String username = (String)httpSession.getAttribute("username");
        List<Patient> patientList = patientService.findAll(1, 10);
        PageInfo<Patient> pageInfo = new PageInfo<>(patientList);
        model.addAttribute("pageinfo", pageInfo);
        model.addAttribute("username", username);

        System.out.println(username + "返回到首页。");
        return "navigator";
    }

    //此处实现的是删除相关的病症，目前还没有应用到系统中
    @RequestMapping("/deleteanatomydict")
    public String deleteAnatomyDict(@RequestParam("anatomyname")String anatomyname, Model model){
        doctorService.deleteAnatomyDict(anatomyname);
        System.out.println(anatomyname + "删除成功");
        return "anatomyDict";
    }

    //此处实现的是更新病人的相关信息，目前还没有应用到系统中
    @RequestMapping("/updatepatient")
    public String updatePatient(@RequestParam("patientname")String patientname,
                                @RequestParam("clinicaldiagnosis")String clinicaldiagnosis,
                                Model model){
        doctorService.updatePatient(patientname, clinicaldiagnosis);
        model.addAttribute("patientname", patientname);
        model.addAttribute("clinicaldiagnosis", clinicaldiagnosis);
        return "updatePatient";
    }

    @RequestMapping("/register")
    public String register(){
        return "registerDoctor";
    }

    //此处实现的是注册，缺失功能：验证是否重复
    @RequestMapping("/registerdoctor")
    public String registerDoctor(@RequestParam("userid")String userid,
                                 @RequestParam("departmentid")String departmentid,
                                 @RequestParam("hospitalid")String hospitalid,
                                 @RequestParam("username")String username,
                                 @RequestParam("gender")String gender,
                                 @RequestParam("age")String age,
                                 Model model){
        if(userid == null || departmentid == null || username == null || hospitalid == null){
            System.out.println("用户信息不符合规范");
            return "error";
        }else{
            Doctor doctor = new Doctor();
            doctor.setAge(age);
            doctor.setGender(gender);
            doctor.setHospitalid(hospitalid);
            doctor.setDepartmentid(departmentid);
            doctor.setUsername(username);
            doctor.setUserid(userid);
            doctorService.registerDoctor(doctor);

            System.out.println("添加用户成功");
            //model.addAttribute("message", "用户注册成功!");
            return "index";
        }

    }

    @ResponseBody   //返回给jsp的字符串格式
    @RequestMapping(value = "checkid", method = RequestMethod.POST)
    public Message checkid(String userid,
                        HttpServletRequest request,
                        HttpServletResponse response) throws IOException {
        String username = doctorService.checkId(userid);
        System.out.println("用户输入的用户ID为" + userid + ", 查找数据库中的姓名为" + username);

        String test = request.getParameter("userid");
        System.out.println("getParameter得到的id为" + test);

        int flag = 0;
        if(userid.isEmpty()){
            flag = 1;
        }
        System.out.println("flag=" + flag);

        //将查询结果写到响应包
        if(username != null){
            response.getWriter().println("false");
        }else{
            if(flag == 1){
                response.getWriter().println("error");
            }else{
                response.getWriter().println("true");
            }

        }

        if(username == null){
            Message msg = new Message("yes");
            System.out.println(msg.toString() + " 用户ID可以使用");
            return msg;
        }else {
            Message msg = new Message("no");
            System.out.println(msg.toString() + " 用户ID已被使用");
            return msg;
        }


//        if (username != null){
//            return "{\"msg\": \"false\"}";
//        }else {
//            return "{\"msg\": \"true\"}";
//        }
    }

    //此处实现的是根据姓名和用户ID登录
    @RequestMapping("/login")
    public String verifyDoctor(@RequestParam("username")String username,
                               @RequestParam("userid")String userid,
                               HttpSession httpSession,
                               Model model){
        if(username != null){
            if(userid.equals(doctorService.verifyDoctor(username))){
                List<Patient> patientList = patientService.findAll(1, 10);
                PageInfo<Patient> pageInfo = new PageInfo<>(patientList);

                model.addAttribute("pageinfo", pageInfo);
                model.addAttribute("username", username);
                httpSession.setAttribute("username", username);
                httpSession.setAttribute("pageinfo", pageInfo);

                System.out.println("用户名为" + username + "的用户登录成功!");
                return "navigator";
            }else{
                System.out.println("用户名为" + username + "的用户登录失败!");
                model.addAttribute("message", "用户名或密码错误!");
                return "index";
            }
        }else{
            model.addAttribute("message", "用户名不能为空!");
            return "index";
        }

    }

    //此功能实现的是查询所有病人，并且分页
    @RequestMapping("/findall")
    public String findAll(@RequestParam(defaultValue = "1")int page,
                          @RequestParam(defaultValue = "10")int size,
                          HttpSession httpSession,
                          Model model){
        List<Patient> patients = patientService.findAll(page, size);
        PageInfo<Patient> pageInfo = new PageInfo<>(patients);
        model.addAttribute("patient", patients);
        model.addAttribute("pageInfo", pageInfo);

        String username = (String) httpSession.getAttribute("username");
        model.addAttribute("username", username);

        System.out.println(username + "查找了所有的病人!");
        return "resFindAll";
    }

    @RequestMapping("/findpatientbyname")
    public String findPatient(@RequestParam("patientname")String patientname,
                              HttpSession httpSession,
                              Model model){
        Patient patient = patientService.findPatientByName(patientname);
        httpSession.setAttribute("patientname", patientname);
        String patientnameget = (String) httpSession.getAttribute("patientname");
        System.out.println("存入session的patientname为" + patientnameget);
        model.addAttribute("patient", patient);
        model.addAttribute("patientname", patientname);
        System.out.println("查询姓名为" + patientname + "的病人");
        return "resFindPatientByName";
    }

    @RequestMapping("/findPatientByDict")
    public String findPatientByDict(String diseasename,
                                    @RequestParam(defaultValue = "1")int page,
                                    @RequestParam(defaultValue = "10")int size,
                                    HttpSession httpSession,
                                    Model model){
        if(diseasename != null){
            httpSession.setAttribute("diseasename", diseasename);
        }else{
            diseasename = (String)httpSession.getAttribute("diseasename");
        }

        System.out.println("要查询病名为" + diseasename + "的病人");
        List<Patient> patients = doctorService.findPatientByDict(page, size, diseasename);
        PageInfo<Patient> pageInfo = new PageInfo<>(patients);

        String username = (String) httpSession.getAttribute("username");
        httpSession.setAttribute("diseasename", diseasename);
        model.addAttribute("username", username);
        model.addAttribute("diseasename", diseasename);
        model.addAttribute("pageInfo", pageInfo);

        return "resFindPatientByDiseaseDict";
    }

    //此处实现的是删除病例
    @RequestMapping("/deletepatient")
    public String deletePatient(HttpSession httpSession,
                                Model model){
        String username = (String) httpSession.getAttribute("username");
        String patientname = (String) httpSession.getAttribute("patientname");
        System.out.println(username + "要删除的用户是" + patientname);
        doctorService.deletePatient(patientname);

        //这里主要是返回首页的所需要的相关信息
        List<Patient> patientList = patientService.findAll(1, 10);
        PageInfo<Patient> pageInfo = new PageInfo<>(patientList);
        model.addAttribute("username", username);
        model.addAttribute("pageinfo", pageInfo);
        return "navigator";
    }

    @RequestMapping("/update")
    public String updatePatient(@RequestParam("patientname")String patientname,
                                HttpSession httpSession,
                                Model model){
        model.addAttribute("patientname", patientname);
        httpSession.setAttribute("patientname", patientname);
        String username = (String) httpSession.getAttribute("username");
        List<Patient> patientList = patientService.findAll(1, 10);
        PageInfo<Patient> pageInfo = new PageInfo<>(patientList);
        model.addAttribute("username", username);
        model.addAttribute("pageinfo", pageInfo);

        Patient patient = patientService.findPatientByName(patientname);
        model.addAttribute("Patient", patient);

        System.out.println("即将对" + patientname + "的信息进行更新");
        return "updatePatient";
    }

    @RequestMapping("/updateclinicaldiagnosis")
    public String updateClinicalDiagnosis(@RequestParam("clinicaldiagnosis")String clinicaldiagnosis,
                                          HttpSession httpSession,
                                          Model model){
        String patientname = (String) httpSession.getAttribute("patientname");
        doctorService.updatePatient(patientname, clinicaldiagnosis);

        String username = (String) httpSession.getAttribute("username");
        List<Patient> patientList = patientService.findAll(1, 10);
        PageInfo<Patient> pageInfo = new PageInfo<>(patientList);
        model.addAttribute("username", username);
        model.addAttribute("pageinfo", pageInfo);
        System.out.println("即将返回首页。");
        return "navigator";
    }

}
