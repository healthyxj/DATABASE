package cn.doc.controller;

import cn.doc.entity.PageInfoSelf;
import cn.doc.entity.Patient;
import cn.doc.service.PatientService;
import com.github.pagehelper.PageInfo;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import javax.annotation.Resource;
import javax.servlet.http.HttpSession;
import java.util.List;

@Controller
@RequestMapping("/Patient")
public class PatientController {

    @Resource
    private PatientService patientService;

    @RequestMapping("/findpatientbyname")
    public String findPatient(@RequestParam("patientname")String patientname,
                              Model model){
        Patient patient = patientService.findPatientByName(patientname);
        model.addAttribute("patient", patient);
        return "resFindPatientByName";
    }

    //此功能实现的是根据病例查询病人，分页失败
    @RequestMapping("/findpatientbydict")
    public String findPatientByDict(@RequestParam(defaultValue = "1")int currentPage,
                                    @RequestParam("diseasename")String diseasename,
                                    HttpSession httpSession,
                                    Model model){
        if(diseasename != null){
            httpSession.setAttribute("diseasename", diseasename);
        }else{
            diseasename = (String) httpSession.getAttribute("diseasename");
        }

        List<Patient> patients = patientService.findPatientByDict(currentPage, diseasename);
        PageInfo<Patient> pageInfo = new PageInfo<>(patients);
        System.out.println("当前要查找的页数为" + currentPage + ", 病名为" + diseasename);

        model.addAttribute("pageInfo", pageInfo);
        model.addAttribute("diseasename", diseasename);


//        model.addAttribute("pageInfo", pageInfo);
//        model.addAttribute("patients",patients);
        return "resFindPatientByDiseaseDict";
    }

    //此功能实现的是查询所有病人，并且分页
    @RequestMapping("/findall")
    public String findAll(@RequestParam(defaultValue = "1")int page,
                          @RequestParam(defaultValue = "10")int size,
                          Model model){
        List<Patient> patients = patientService.findAll(page, size);
        PageInfo<Patient> pageInfo = new PageInfo<>(patients);
        model.addAttribute("patient", patients);
        model.addAttribute("pageInfo", pageInfo);
        return "resFindAll";
    }
}
