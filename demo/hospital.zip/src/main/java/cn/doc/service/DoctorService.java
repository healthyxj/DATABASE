package cn.doc.service;

import cn.doc.entity.Doctor;
import cn.doc.entity.Patient;
import org.apache.ibatis.annotations.Param;

import java.util.List;

public interface DoctorService {

    void deleteAnatomyDict(String anatomyname);

    void updatePatient(@Param("patientname")String patientname, @Param("clinicaldiagnosis")String clinicaldiagnosis);

    void registerDoctor(Doctor doctor);

    String verifyDoctor(String username);

    void deletePatient(String patientName);

    String checkId(String userid);

    List<Patient> findPatientByDict(int page, int size, String diseasename);
}
