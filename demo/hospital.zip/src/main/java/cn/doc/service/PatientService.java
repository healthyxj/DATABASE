package cn.doc.service;

import cn.doc.entity.Patient;

import java.util.List;

public interface PatientService {

    public Patient findPatientByName(String patientname);

    public List<Patient> findPatientByDict(int start, String dict);

    public List<Patient> findAll(int page, int size);
}
