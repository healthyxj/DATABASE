package cn.doc.service;

import cn.doc.dao.PatientDao;
import cn.doc.entity.PageInfoSelf;
import cn.doc.entity.Patient;
import com.github.pagehelper.PageHelper;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;
import java.util.List;

/*
* PatientService对应的实现类
* */

@Service("patientService")
public class PatientServiceImpl implements PatientService{

    @Resource
    private PatientDao patientDao;

    public Patient findPatientByName(String patientname){
        return patientDao.findPatientByName(patientname);
    }

    public List<Patient> findPatientByDict(int currentPage, String dict){
        PageInfoSelf<Patient> pageInfoSelf = new PageInfoSelf<>();
        pageInfoSelf.setSize(10);

        //统计病例的人数
        int tc = patientDao.countNum(dict);
        pageInfoSelf.setTotalCount(tc);
        //tp为总页数
        int tp = (int)Math.ceil(tc / 5.0);
        pageInfoSelf.setTotalPage(tp);

        if(currentPage < 1){
            pageInfoSelf.setCurrentPage(1);
        }else pageInfoSelf.setCurrentPage(Math.min(currentPage, tp));

        int start = (pageInfoSelf.getCurrentPage() - 1) * 10;
        List<Patient> patientList = patientDao.findPatientByDict(start, dict);
        pageInfoSelf.setList(patientList);
        return patientList;
    }

    public List<Patient> findAll(int page, int size){
        PageHelper.startPage(page, size);
        return patientDao.findAll();
    }

}
