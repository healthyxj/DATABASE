package cn.doc.service;

import cn.doc.dao.DoctorDao;
import cn.doc.entity.Doctor;
import cn.doc.entity.Patient;
import com.github.pagehelper.PageHelper;
import org.apache.ibatis.annotations.Param;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;
import java.util.List;

@Service("doctorService")
public class DoctorServiceImpl implements DoctorService{

    @Resource
    private DoctorDao doctorDao;

    public void deleteAnatomyDict(String anatomyname){
        doctorDao.deleteAnatomyDict(anatomyname);
    }

    public void updatePatient(@Param("patientname")String patientname, @Param("clinicaldiagnosis")String clinicaldiagnosis){
        System.out.println(patientname + "信息更新成功!");
        doctorDao.updatePatient(patientname, clinicaldiagnosis);
    }

    public void registerDoctor(Doctor doctor){
        doctorDao.registerDoctor(doctor);
    }

    public String verifyDoctor(String username){
        return doctorDao.verifyDoctor(username);
    }

    public void deletePatient(String patientName){
        doctorDao.deletePatient(patientName);
    }

    public String checkId(String userid){
        return doctorDao.checkId(userid);
    }

    public List<Patient> findPatientByDict(int page, int size, String diseasename){
        PageHelper.startPage(page, size);
        return doctorDao.findPatientByDict(diseasename);
    }
}
