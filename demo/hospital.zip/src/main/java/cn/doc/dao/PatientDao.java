package cn.doc.dao;

import cn.doc.entity.Patient;
import org.apache.ibatis.annotations.Param;
import org.springframework.web.bind.annotation.RequestParam;

import java.util.List;

public interface PatientDao {

    //根据病人的ID查找对应的病人
    Patient findPatientByName(String patientname);

    //根据标注查找病人
    List<Patient> findPatientByDict(@Param("start") int start, @Param("diseasename") String dict);

//    //根据标注查找病人，并且分页
//    List<Patient> findPatientByDictWP(int start, String dict);

    List<Patient> findAll();

    //根据标记名称统计数量
    int countNum(@Param("diseasename") String dict);
}
