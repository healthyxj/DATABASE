package cn.doc.entity;

/*
* Doctor实体类
*
* @author: @hxj
* @create: 2021-06-13 19:11
* */

public class Doctor {

    private int id;
    private String userid; //表示登录的密码
    private String username;    //表示中文名，因为表是固定的，所以采用中文名作为用户名
    private String departmentid;    //表示所属科室
    private String hospitalid;  //表示医院的ID
    private String gender;
    private String age;

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getUserid() {
        return userid;
    }

    public void setUserid(String userid) {
        this.userid = userid;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public String getDepartmentid() {
        return departmentid;
    }

    public void setDepartmentid(String departmentid) {
        this.departmentid = departmentid;
    }

    public String getHospitalid() {
        return hospitalid;
    }

    public void setHospitalid(String hospitalid) {
        this.hospitalid = hospitalid;
    }

    public String getGender() {
        return gender;
    }

    public void setGender(String gender) {
        this.gender = gender;
    }

    public String getAge() {
        return age;
    }

    public void setAge(String age) {
        this.age = age;
    }
}
