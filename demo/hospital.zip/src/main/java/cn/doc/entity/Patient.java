package cn.doc.entity;

import java.util.Date;

/*
* Patient 实体类
*
* @author:@hxj
* */

public class Patient {

    private int id;
    private Date checkdate;
    private String checknumber;
    private String patientid;
    private String patientname;
    private String gender;
    private String age;
    private String clinicaldiagnosis;
    private String examinationfindings;
    private String endoscopicdiagnosis;
    private String pathologicaldiagnosis;
    private String patientreport;
    private String hospitalid;

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public Date getCheckdate() {
        return checkdate;
    }

    public void setCheckdate(Date checkdate) {
        this.checkdate = checkdate;
    }

    public String getChecknumber() {
        return checknumber;
    }

    public void setChecknumber(String checknumber) {
        this.checknumber = checknumber;
    }

    public String getPatientid() {
        return patientid;
    }

    public void setPatientid(String patientid) {
        this.patientid = patientid;
    }

    public String getPatientname() {
        return patientname;
    }

    public void setPatientname(String patientname) {
        this.patientname = patientname;
    }

    public String getGender() {
        return gender;
    }

    public void setGender(String gender) {
        this.gender = gender;
    }

    public String getAge() {
        return age;
    }

    public void setAge(String age) {
        this.age = age;
    }

    public String getClinicaldiagnosis() {
        return clinicaldiagnosis;
    }

    public void setClinicaldiagnosis(String clinicaldiagnosis) {
        this.clinicaldiagnosis = clinicaldiagnosis;
    }

    public String getExaminationfindings() {
        return examinationfindings;
    }

    public void setExaminationfindings(String examinationfindings) {
        this.examinationfindings = examinationfindings;
    }

    public String getEndoscopicdiagnosis() {
        return endoscopicdiagnosis;
    }

    public void setEndoscopicdiagnosis(String endoscopicdiagnosis) {
        this.endoscopicdiagnosis = endoscopicdiagnosis;
    }

    public String getPathologicaldiagnosis() {
        return pathologicaldiagnosis;
    }

    public void setPathologicaldiagnosis(String pathologicaldiagnosis) {
        this.pathologicaldiagnosis = pathologicaldiagnosis;
    }

    public String getPatientreport() {
        return patientreport;
    }

    public void setPatientreport(String patientreport) {
        this.patientreport = patientreport;
    }

    public String getHospitalid() {
        return hospitalid;
    }

    public void setHospitalid(String hospitalid) {
        this.hospitalid = hospitalid;
    }
}
