package cn.doc.entity;

public class Message {
    private String msg;
    private Patient patient;

    public Message(String msg) {
        this.msg = msg;
    }

    public Message(Patient patient) {
        this.patient = patient;
    }

    public Message() {
    }

    public String getMsg() {
        return msg;
    }

    public void setMsg(String msg) {
        this.msg = msg;
    }

    public Patient getPatient() {
        return patient;
    }

    public void setPatient(Patient patient) {
        this.patient = patient;
    }

    @Override
    public String toString(){
        return "msg:" + msg;
    }
}
