import cn.doc.dao.DoctorDao;
import cn.doc.entity.Doctor;
import cn.doc.entity.Patient;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import java.util.List;


@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration({"classpath:spring-mybatis.xml"})
public class DoctorDaoTest {

    @Autowired
    private DoctorDao doctorDao;

//    @Test
//    public void testDeleteAnatomyDict(){
//        String anatomyname = "内部";
//        doctorDao.deleteAnatomyDict(anatomyname);
//
//    }

//    @Test
//    public void testUpdatePatient(){
//        String patientname = "李金良";
//        String clinicaldiagnosis = "胃癌";
//        doctorDao.updatePatient(patientname, clinicaldiagnosis);
//        System.out.println(patientname + "的诊断结果修改为了" + clinicaldiagnosis);
//    }

//    @Test
//    public void testRegisterDoctor(){
//        Doctor doctor = new Doctor();
//        doctor.setUserid("kaira");
//        doctor.setDepartmentid("消化科");
//        doctor.setHospitalid("浙江省中医院");
//        doctor.setUsername("凯拉");
//        doctor.setGender("女");
//        doctor.setAge("31");
//        doctorDao.registerDoctor(doctor);
//        System.out.println("数据插入成功！");
//    }

//    @Test
//    public void testVerifyDoctor(){
//        String username = "胡骁健";
//        String userid = doctorDao.verifyDoctor(username);
//        System.out.println("胡骁健的用户ID为" + userid);
//    }

//    @Test
//    public void testDeletePatient(){
//        String patientName = "钱学生";
//        doctorDao.deletePatient(patientName);
//        System.out.println("该记录已被删除");
//    }

//    @Test
//    public void testCheckId(){
//        String userid = "Geralt";
//        String name = doctorDao.checkId(userid);
//        System.out.println("用户ID为" + userid + "的姓名为" + name);
//    }

    @Test
    public void testFindPatientByDict(){
        String diseasename = "萎缩性胃炎";
        List<Patient> patients = doctorDao.findPatientByDict(diseasename);
        for(Patient patient: patients){
            System.out.println("病人的姓名为" + patient.getPatientname());
        }
    }
}
