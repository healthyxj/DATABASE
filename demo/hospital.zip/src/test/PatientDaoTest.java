import cn.doc.dao.PatientDao;
import cn.doc.entity.Patient;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import java.util.List;

/*
* PatientDao的测试类
*
* @author:@hxj
* */

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration({"classpath:spring-mybatis.xml"})
public class PatientDaoTest {

    @Autowired
    private PatientDao patientDao;

    @Test
    public void testFindPatientByName(){
        String patientname = "李金良";
        Patient patient = patientDao.findPatientByName(patientname);
        System.out.println(patient.getId() + ": " + patient.getPatientname());
    }

//    @Test
//    public void testFindPatientByDict(){
//        String dict = "糜烂";
//        List<Patient> patients = patientDao.findPatientByDict(dict);
//        for (Patient patient : patients) {
//            System.out.println(patient.getId() + ": " + patient.getPatientname());
//        }
//    }

//    @Test
//    public void testFindAll(){
//        List<Patient> patients = patientDao.findAll();
//        for(Patient patient : patients){
//            System.out.println(patient.getId() + ": " + patient.getPatientname());
//        }
//    }

//    @Test
//    public void testFindPatientByDictWP(){
//        int start = 1;
//        String dict = "糜烂";
//        List<Patient> patientList = patientDao.findPatientByDictWP(start, dict);
//        for(Patient patient : patientList){
//            System.out.println(patient.getId() + ": " + patient.getPatientname());
//        }
//    }

    @Test
    public void testCountNum(){
        String dict = "萎缩性胃炎";
        int num = patientDao.countNum(dict);
        System.out.println("疾病标注为萎缩性胃炎的人有" + num + "个");
    }

}
